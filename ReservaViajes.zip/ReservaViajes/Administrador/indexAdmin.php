<?php  
	
	session_start();
	echo "Ingreso Administrador";

	echo $_SESSION["usuario"];
    echo $_SESSION["codusuario"];
    echo $_SESSION["contraseña"];
?>