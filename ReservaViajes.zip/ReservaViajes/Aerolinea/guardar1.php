
<?php
    session_start();

    $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";

    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));

   
    $aero=$_POST['tipoae'];
    $av=$_POST['tipoav'];
    $fecha=$_POST['fecha'];
    $co=$_POST['tipoco'];
    $cd=$_POST['tipocd'];
    $cant=$_POST['cant'];
    
    //$resultado=mysqli_query( $conexion,"SELECT * FROM VUELO WHERE nom_avion = '$nom' ");
 
    if (mysqli_num_rows($resultado)>0)
    {
      ?>
      <meta http-equiv="refresh" content="0; url=NuevoVuelo.php" />

      <?php
 
    } else {

      $insert_value = 'INSERT INTO VUELO  VALUES (0,"'.$aero.'","' . $av.'","' . $fecha.'","' . $co.'","' . $cd.'","'.$cant.'")';
       mysqli_select_db( $conexion,$bd);
       $retry_value = mysqli_query( $conexion,$insert_value);
      
     if (!$retry_value) {
       die('Error: ' . mysqli_error($conexion));
       
    }
 
    ?>
       <meta http-equiv="refresh" content="0; url=indexAerolinea.php" />

    <?php
}
 
mysqli_close($conexion);

 
?>




    
  







  