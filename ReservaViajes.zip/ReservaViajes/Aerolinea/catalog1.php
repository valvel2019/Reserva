<!DOCTYPE html>
<html>
<head>
 <title>Catálogo</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="Shortcut Icon" type="image/x-icon" href="assets/icons/logoo.ico" />
    <script src="js/sweet-alert.min.js"></script>
    <link rel="stylesheet" href="css/sweet-alert.css">
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/main.js"></script>
     <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
   

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>
<body>
    <div class="navbar-lateral full-reset">
        <div class="visible-xs font-movile-menu mobile-menu-button"></div>
        <div class="full-reset container-menu-movile custom-scroll-containers">
            <div class="logo full-reset all-tittles">
                <i class="visible-xs zmdi zmdi-close pull-left mobile-menu-button" style="line-height: 55px; cursor: pointer; padding: 0 10px; margin-left: 7px;"></i> 
                sistema de Reservas de viajes
            </div>
            <div class="full-reset" style="background-color:#2B3D51; padding: 10px 0; color:#fff;">
                <figure>
                    <img src="assets/img/logo.jpg" alt="Biblioteca" class="img-responsive center-box" style="width:100%;">
                </figure>
                <p class="text-center" style="padding-top: 15px;">Sistemade Reservas de viajes</p>
            </div>
             <div class="full-reset nav-lateral-list-menu">
                <ul class="list-unstyled">
                    <li><a href="indexAerolinea.php"><i class="zmdi zmdi-home zmdi-hc-fw"></i>&nbsp;&nbsp; Inicio</a></li>
                    
                    
                    <li>
                        <div class="dropdown-menu-button"><i class="zmdi zmdi-airplane"></i>&nbsp;&nbsp; Aviones y listado <i class="zmdi zmdi-chevron-down pull-right zmdi-hc-fw"></i></div>
                        <ul class="list-unstyled">
                            <li><a href="NuevoAvion.php"><i class="zmdi zmdi-airplane"></i>&nbsp;&nbsp; Nuevo Avión</a></li>
                            <li><a href="catalog1.php"><i class="zmdi zmdi-bookmark-outline zmdi-hc-fw"></i>&nbsp;&nbsp; Listado</a></li>
                        </ul>
                    </li>
                    <li>
                        <div class="dropdown-menu-button"><i class="zmdi zmdi-timer"></i>&nbsp;&nbsp; Vuelos y listado <i class="zmdi zmdi-chevron-down pull-right zmdi-hc-fw"></i></div>
                        <ul class="list-unstyled">
                            <li><a href="NuevoVuelo.php"><i class="zmdi zmdi-timer"></i>&nbsp;&nbsp; Nuevo Vuelo</a></li>
                            <li><a href="catalog2.php"><i class="zmdi zmdi-bookmark-outline zmdi-hc-fw"></i>&nbsp;&nbsp; Listado</a></li>
                        </ul>
                    </li>
                   
                   
                </ul>
            </div>
        </div>
    </div>
    <div class="content-page-container full-reset custom-scroll-containers">
        <nav class="navbar-user-top full-reset">
            <ul class="list-unstyled full-reset">
                <figure>
                   <img src="assets/img/user01.png" alt="user-picture" class="img-responsive img-circle center-box">
                </figure>
                 <li style="color:#fff; cursor:default;">
                   <span class="all-tittles"><?php echo $_SESSION["usuario"] ?></span>
                </li>
               
                <li  class="tooltips-general exit-system-button" data-href="../index.php" data-placement="bottom" title="Salir del sistema">
                    <i class="zmdi zmdi-power"></i>
                </li>
                <li  class="tooltips-general search-book-button" data-href="searchbook.html" data-placement="bottom" title="Buscar Avión">
                    <i class="zmdi zmdi-search"></i>
                </li>
                <li  class="tooltips-general btn-help" data-placement="bottom" title="Ayuda">
                    <i class="zmdi zmdi-help-outline zmdi-hc-fw"></i>
                </li>
                <li class="mobile-menu-button visible-xs" style="float: left !important;">
                    <i class="zmdi zmdi-menu"></i>
                </li>
            </ul>
        </nav>


<div class="container">
    <div class="page-header">
              <h1 class="all-tittles">Sistema de Reservas de viajes <small>Catálogo de Aviones</small></h1>
            </div>
        </div>
         <div class="container-fluid"  style="margin: 40px 0;">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-3">
                    <img src="assets/img/avionicon.jpg" alt="pdf" class="img-responsive center-box" style="max-width: 110px;">
                </div>
                <div class="col-xs-12 col-sm-8 col-md-8 text-justify lead">
                    Bienvenido al catálogo, selecciona una categoría de la lista para modificar o eliminar, si deseas  &nbsp; <i class="zmdi zmdi-search"></i> &nbsp; 
                </div>
            </div>
        </div>
 
    <?php require_once 'process.php'; ?>

  <?php
   if(isset($_SESSION['message'])): ?>
    <div class="alert alert-<?=$_SESSION['msg_type']?>">
      <?php
        echo $_SESSION['message'];
        unset($_SESSION['message']);
        ?>
      </div>
    <?php endif ?>

  <div class="container">
  <?php
    $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";


    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
    $result=$conexion->query("SELECT * FROM AVION") or die($conexion->error);
    //pre_r($result);
    ?>
    <link rel="stylesheet"  href="estilos.css">
    <div id="main-container">
    <div class="row justify-content-center">
        <table class="table">
        <thead>
          <tr>
              <th>Id</th>
              <th>Nombre</th>
             
              <th>Capacidad </th>
              
              <th colspan="3">Acción
               
              </th>
       
          </tr>
        </thead>
      <?php
        while ($row = $result->fetch_assoc()): ?>
            <tr>
               
                <td align="center"><?php echo $row['cod_avion']; ?></td>
                <td align="center"><?php echo $row['nom_avion']; ?></td>
                <td align="center"><?php echo $row['cant_pasajeros']; ?></td>
                
               <td>
               <a href="process.php?delete1=<?php echo $row['cod_avion']; ?>"
               ><button class="button" class="btn btn-danger">Borrar</button></a>
               <a href="prueba.php?editar=<?php echo $row['cod_avion']; ?>"
               ><button class="button" class="btn btn-info">Editar</button></a>
               </td>
            </tr>
    <?php endwhile; ?>
      </table>
      </div>
    </div>
      <?php
        function pre_r($array){
          echo '<pre>';
          print_r($array);
          echo '</pre>';
        }
        ?>

    
   
</div>






</div>

</body>
</html>
