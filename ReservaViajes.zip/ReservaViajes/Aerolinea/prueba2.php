<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
  font-family: "Arial", sans-serif;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #A2A2A2;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #1D2A42;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;

}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
* {box-sizing: border-box;}

/* Style the input container */
.input-container {
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

/* Style the form icons */
.icon {
  padding: 10px;
  background: #00912f;
  color: black;
  min-width: 50px;
  text-align: center;
}

/* Style the input fields */
.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}

.input-field:focus {
  border: 2px solid #00912f;
}

/* Set a style for the submit button */
.btn {
  background-color: #1D2A42;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="Shortcut Icon" type="image/x-icon" href="assets/icons/logoo.ico" />
    <script src="js/sweet-alert.min.js"></script>
    <link rel="stylesheet" href="css/sweet-alert.css">
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/main.js"></script>
</style>
<title> Modificar Vuelo </title>
</head>
<div class="sidebar">
  <a class="active" href="catalog2.php">Regresar</a>
</div>

<div class="content">
<?php
 
 $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";
    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
        $id=0;
         $update=false;
         $name='';
         $codigo='';
          $cant='';
      if(isset($_GET['editar'])){
      $id=$_GET['editar'];
    	
    	$result=$conexion->query("SELECT * FROM VUELO WHERE cod_vuelo=$id") or die($conexion->error());
    	if(count($result)==1){
    		$row=$result->fetch_array();

    		$codigo=$row['cod_vuelo'];
        $aer=$row['cod_aerolinea'];
        $av=$row['cod_avion'];
        $fecha=$row['f_vuelo'];
        $co=$row['cod_c_origen'];
        $cd=$row['cod_c_destino'];
        $cant=$row['asien_disponibles'];
    }
  }
    ?>
 <div class="form-group">
            
 <h1>Modificación de un vuelo</h1>
 <form action="M_vuelo.php" method="POST">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
    <div class="input-container">
    <label >Codigo</label>
    </div>
   
    <div class="input-container">
    <input class="input-field" type="text" value="<?php echo $codigo; ?>"  placeholder="Codigo del vuelo" name="cod" required="true">
    </div>
     <div class="input-container">
    
                                      <label>Aerolinea</label>
                             </div>
                             <div class="input-container">
  
                                <?php
    
                                 $server = "localhost";
                                 $user = "root";
                                 $pass = "";
                                 $bd = "travelweb";


                                 $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
                                 $result=$conexion->query("SELECT  cod_aerolinea, nom_aerolinea FROM AEROLINEA") or die($conexion->error); 
 
                                ?>
                             <select class="input-field" value="<?php echo $aer; ?>" name="tipoae" required>
                                <?php
                                   while($row = $result->fetch_assoc()): ?>
                                   <option value="<?php echo $row['cod_aerolinea']; ?>" > <?php echo $row['cod_aerolinea']; ?> <?php echo $row['nom_aerolinea']; ?> </option>
                                  

          
          
                                <?php endwhile; ?>
                                 <input class="input-field" type="text" value="<?php echo $aer; ?>"  placeholder="Codigo del vuelo" name="tipoae" required="true">
                             </select>
      
                             </div>
                                 

                             <div class="input-container">
                                      <label>Avion</label>
                             </div>
                             <div class="input-container">
  
                                <?php
    
                                 $server = "localhost";
                                 $user = "root";
                                 $pass = "";
                                 $bd = "travelweb";


                                 $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
                                 $result=$conexion->query("SELECT  cod_avion, nom_avion FROM AVION") or die($conexion->error); 
 
                                ?>
                             <select class="input-field" value="<?php echo $av; ?>"name="tipoav" required>
                                <?php
                                   while($row = $result->fetch_assoc()): ?>
                                   <option value="<?php echo $row['cod_avion']; ?>" > <?php echo $row['cod_avion']; ?> <?php echo $row['nom_avion']; ?> </option>

          
                                <?php endwhile; ?>
                                 <input class="input-field" type="text" value="<?php echo $av; ?>"  placeholder="Codigo del vuelo" name="tipoav" required="true">
          
                             </select>
                         </div>

                              <div class="input-container">
                                      <label>Fecha</label>
                             </div>
                           <tr>
                            <td><input type="date" value="<?php echo $fecha; ?>" id="fecha" name="fecha" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" min="2019-24-11" max="2020-04-23"/></td>
                        </tr>
              

                           <div class="input-container">
                                      <label>Ciudad Origen </label>
                             </div>
                             <div class="input-container">
  
                                <?php
    
                                 $server = "localhost";
                                 $user = "root";
                                 $pass = "";
                                 $bd = "travelweb";


                                 $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
                                 $result=$conexion->query("SELECT  cod_ciudad, nom_ciudad FROM CIUDAD") or die($conexion->error); 
 
                                ?>
                             <select class="au-input au-input--full" name="tipoco" required>
                                <?php
                                   while($row = $result->fetch_assoc()): ?>
                                   <option value="<?php echo $row['cod_ciudad']; ?>" > <?php echo $row['cod_ciudad']; ?><?php echo $row['nom_ciudad']; ?> </option>
          
          
                                <?php endwhile; ?>
                                 <input class="input-field" type="text"  value="<?php echo $co; ?>" placeholder="Codigo del vuelo" name="tipoco" required="true">
                             </select>
                         </div>
                         <div class="input-container">
                                      <label>Ciudad Destino </label>
                             </div>
                             <div class="input-container">
  
                                <?php
    
                                 $server = "localhost";
                                 $user = "root";
                                 $pass = "";
                                 $bd = "travelweb";


                                 $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
                                 $result=$conexion->query("SELECT  cod_ciudad, nom_ciudad FROM CIUDAD") or die($conexion->error); 
 
                                ?>
                             <select class="au-input au-input--full" value="<?php echo $cd; ?>" " required>
                                <?php
                                   while($row = $result->fetch_assoc()): ?>
                                   <option value="<?php echo $row['cod_ciudad']; ?>" >  <?php echo $row['cod_ciudad']; ?> <?php echo $row['nom_ciudad']; ?> </option>
          
          
                                <?php endwhile; ?>
                                 <input class="input-field" type="text" value="<?php echo $cd; ?>"  placeholder="Codigo del vuelo" name="tipocd" required="true">
                             </select>
                         </div>
                          <div class="input-container">
                                      <label>Cantidad (debe coincidir con el avion escogido)</label>
                             </div>
                             <div class="input-container">
  
                                <?php
    
                                 $server = "localhost";
                                 $user = "root";
                                 $pass = "";
                                 $bd = "travelweb";


                                 $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
                                 $result=$conexion->query("SELECT  cod_avion, nom_avion,cant_pasajeros FROM AVION") or die($conexion->error); 
 
                                ?>
                             <select class="au-input au-input--full" required>
                                <?php
                                   while($row = $result->fetch_assoc()): ?>
                                   <option value="<?php echo $row['cant_pasajeros']; ?>" > <?php echo $row['cod_avion']; ?> <?php echo $row['nom_avion'] ; ?> <?php echo $row['cant_pasajeros'] ; ?> </option>
          
          
                                <?php endwhile; ?>
                                  <input class="input-field" type="text" value="<?php echo $cant; ?>"  placeholder="Codigo del vuelo" name="cant" required="true">

                             </select>
                         </div>

 
    
    <button type="submit"  class="btn btn-info" name="update">Update</button>
     
    
   
  
   

</form>
</div>
</div>
  

</html>