<?php
session_start();

$server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";
    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
         $id=0;
         $update=false;
         $name='';
         $codigo='';
         $cant='';
   
    if(isset($_POST['update'])){
      $id=$_POST['cod'];
      $name=$_POST['nom'];
      $cant=$_POST['cant'];
      $conexion->query("UPDATE AVION SET nom_avion='$name' , cant_pasajeros='$cant' WHERE cod_avion=$id ") or die($conexion->error());
      $_SESSION['message']="record has been updated";
      $_SESSION['msg_type']="warning";
    header('Location: catalog1.php');
}


?>