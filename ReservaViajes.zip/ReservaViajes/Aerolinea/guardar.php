
<?php
    session_start();

    $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";

    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));

   
    
    $nom=$_POST['nombre'];
    $capa=$_POST['capa'];
    
    $resultado=mysqli_query( $conexion,"SELECT * FROM AVION WHERE nom_avion = '$nom' ");
 
    if (mysqli_num_rows($resultado)>0)
    {
      ?>
      <meta http-equiv="refresh" content="0; url=NuevoAvion.php" />

      <?php
 
    } else {

      $insert_value = 'INSERT INTO AVION  VALUES (0,"'.$nom.'","' . $capa.'")';
       mysqli_select_db( $conexion,$bd);
       $retry_value = mysqli_query( $conexion,$insert_value);
      
     if (!$retry_value) {
       die('Error: ' . mysqli_error($conexion));
       
    }
 
    ?>
       <meta http-equiv="refresh" content="0; url=indexAerolinea.php" />

    <?php
}
 
mysqli_close($conexion);

 
?>




    
  







  