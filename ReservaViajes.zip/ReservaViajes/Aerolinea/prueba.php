<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
  font-family: "Arial", sans-serif;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #A2A2A2;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #1D2A42;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;

}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
* {box-sizing: border-box;}

/* Style the input container */
.input-container {
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

/* Style the form icons */
.icon {
  padding: 10px;
  background: #00912f;
  color: black;
  min-width: 50px;
  text-align: center;
}

/* Style the input fields */
.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}

.input-field:focus {
  border: 2px solid #00912f;
}

/* Set a style for the submit button */
.btn {
  background-color: #1D2A42;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
<title> Modificar Avion </title>
</head>
<div class="sidebar">
  <a class="active" href="catalog1.php">Regresar</a>
</div>

<div class="content">
<?php
 $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";
    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
         $id=0;
         $update=false;
         $name='';
         $codigo='';
          $cant='';
    if(isset($_GET['editar'])){
    	$id=$_GET['editar'];
    	
    	$result=$conexion->query("SELECT * FROM AVION WHERE cod_avion=$id") or die($conexion->error());
    	if(count($result)==1){
    		$row=$result->fetch_array();
    		$codigo=$row['cod_avion'];
        $name=$row['nom_avion'];
        $cant=$row['cant_pasajeros'];
   
    		
    	}
    }
    ?>
<div class="form-group">
 <h1>Modificación de un Avion</h1>
 <form action="M_avion.php" method="POST">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
     <div class="input-container">
    <label >Codigo</label>
    </div>
   
    <div class="input-container">
    <input class="input-field" type="text" value="<?php echo $codigo; ?>"  placeholder="Codigo del Libro" name="cod" required="true">
    </div>
 
    <div class="input-container">
    <label >Nombre</label>
    </div>   
    <div class="input-container">
    <input class="input-field" type="text" value="<?php echo $name; ?>" placeholder="Nombre del Libro"  name="nom" required="true">
    </div> 
    <div class="input-container">
    <label >Cantidad</label>
    </div>   
    <div class="input-container">
    <input class="input-field" type="text" value="<?php echo $cant; ?>" placeholder="Cupo del avion"  name="cant" required="true">
    </div>  
 
    
    <button type="submit"  class="btn btn-info" name="update">Update</button>
     
    
   
  
   

</form>
</div>
</div>
  

</html>