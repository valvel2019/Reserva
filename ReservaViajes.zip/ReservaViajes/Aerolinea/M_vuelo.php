<?php
session_start();

$server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";
    $conexion = new mysqli($server, $user, $pass,$bd) or die(mysqli_error($conexion));
         $id=0;
         $update=false;
         $name='';
         $codigo='';
         $cant='';
   
    if(isset($_POST['update'])){
    
          $id=$_POST['cod'];
        $aer=$_POST['tipoae'];
        $av=$_POST['tipoav'];
        $fecha=$_POST['fecha'];
        $co=$_POST['tipoco'];
        $cd=$_POST['tipocd'];
        $cant=$_POST['cant'];

      $conexion->query("UPDATE VUELO SET cod_aerolinea='$aer',cod_avion='$av',f_vuelo='$fecha',cod_c_origen='$co',cod_c_destino='$cd' , asien_disponibles='$cant' WHERE cod_vuelo=$id ") or die($conexion->error());
      $_SESSION['message']="record has been updated";
      $_SESSION['msg_type']="warning";
    header('Location: catalog2.php');
}


?>