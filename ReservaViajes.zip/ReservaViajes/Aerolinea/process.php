<?php

//session_start();

$server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "travelweb";


    $conexion = new mysqli($server, $user, $pass,$bd) 
        or die(mysqli_error($conexion));
        $id1=0;
        $id2=0;
        $id3=0;
        $id4=0;
        $update=false;
        $codigo='';
        $name='';
        $enfermedad='';
    if(isset($_POST['save'])){
    	$codigo=$_POST['cod'];
    	$name=$_POST['name'];
    	$enfermedad=$_POST['enfermedad'];
    	
    	$conexion->query("INSERT INTO PACIENTE (codigo,nombre,enfermedad) VALUES('$codigo','$name','$enfermedad')") or die($conexion->error);
    	$_SESSION['message']="record has been saved!";
    	$_SESSION['msg_type']="success";
    	header("location: index.php");
    }
    

    if(isset($_GET['delete1'])){
    	$id1=$_GET['delete1'];
    	$conexion->query("DELETE FROM AVION WHERE cod_avion=$id1")or die($conexion->error());
    	$_SESSION['message']="record has been deleted!";
    	$_SESSION['msg_type']="danger";
    	header("location: catalog1.php");

    }
     if(isset($_GET['delete2'])){
        $id2=$_GET['delete2'];
        $conexion->query("DELETE FROM VUELO WHERE cod_vuelo=$id2")or die($conexion->error());
        $_SESSION['message']="record has been deleted!";
        $_SESSION['msg_type']="danger";
        header("location: catalog2.php");

    }
     if(isset($_GET['delete3'])){
        $id3=$_GET['delete3'];
        $conexion->query("DELETE FROM CIUDAD WHERE cod_ciudad=$id3")or die($conexion->error());
        $_SESSION['message']="record has been deleted!";
        $_SESSION['msg_type']="danger";
        header("location: Ciudades.php");

    }
     if(isset($_GET['delete4'])){
        $id4=$_GET['delete4'];
        $conexion->query("DELETE FROM CLIENTE WHERE cod_cliente=$id4")or die($conexion->error());
        $_SESSION['message']="record has been deleted!";
        $_SESSION['msg_type']="danger";
        header("location: Clientes.php");

    }

    if(isset($_GET['edit'])){
    	$id=$_GET['edit'];
    	$update=true;
    	$result=$conexion->query("SELECT * FROM PACIENTE WHERE codigo=$id") or die($conexion->error());
    	if(count($result)==1){
    		$row=$result->fetch_array();
    		$codigo=$row['codigo'];
    		$name=$row['nombre'];
    		$enfermedad=$row['enfermedad'];
    	}
    }
    if(isset($_POST['update'])){
    	$id=$_POST['id'];
    	$name=$_POST['name'];
    	$enfermedad=$_POST['enfermedad'];

    	$conexion->query("UPDATE PACIENTE SET nombre='$name', enfermedad='$enfermedad' WHERE codigo=$id") or die($conexion->error);

        $_SESSION['message']="record has been update";
        $_SESSION['msg_type']="warning";
        header('location: index.php');
    }

    