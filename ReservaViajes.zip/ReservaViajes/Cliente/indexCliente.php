<?php  
	
	session_start();
	echo "Ingreso un Cliente";

	echo $_SESSION["usuario"];
    echo $_SESSION["codusuario"];
    echo $_SESSION["contraseña"];
?>